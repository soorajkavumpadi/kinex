import React, { Component } from "react";

import Layout from "./hoc/Layout/Layout";
import { Route, Switch } from "react-router-dom";
import Geo from "./components/Geo/Geo";
import classes from "./App.module.css";
import analyModal from "./components/analystCompo/analyModal/barChart/analyModal";
import tableModal from "./components/analystCompo/tableModal/tableModal";
import listmodal from "./components/analystCompo/listModal/listModal";
import homePage from "./containers/homePage/homePage";
import multichart from "./components/analystCompo/analyModal/multiChart/multiChart";
import Aux from "./hoc/auxiliar";

class App extends Component {
  render() {
    console.log(React.version);
    return (
      <Aux>
        <div>
          <Route path="/" exact component={homePage} />
        </div>
        <div>
            <Route path="/geo" exact component={Geo} />
            {/*<Route path="/list" exact component={listmodal} />*/}
            <Route path="/table" exact component={tableModal} />

            <Route path="/analytics" exact component={analyModal} />
        </div>
      </Aux>
    );
  }
}

export default App;
