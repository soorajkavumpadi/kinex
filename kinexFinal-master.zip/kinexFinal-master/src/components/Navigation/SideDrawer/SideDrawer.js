import React, { useState, useEffect } from 'react'
import classes from './SideDrawer.module.css'
import Aux from '../../../hoc/auxiliar'
import Backdrop from '../../UI/Backdrop/Backdrop'
import Button from '../../UI/Button/Button'
import Spinner from '../../UI/Spinner/Spinner'
import Input from '../../UI/Input/Input';
import leftArro from '../../../assets/icons/left-arrow.svg'


const sideDrawer = ( props ) => {
    let attachedClassesEin = [classes.SideDrawer, classes.Close]
    if(props.open){
        attachedClassesEin = [classes.SideDrawer, classes.Open]
    }

    const filterDat = [
        {
        name : 'From',
        elementType: 'select',
        elementConfig: {
            options : [
                {value: 'Place 1',displayValue:'Place 1'},
                {value: 'Place 2',displayValue:'Place 2'}
            ]
        },
        value: 'Place 1',
        validation:{
            required: false
        },
        touched: false
        },
        {
            name : 'To',
            elementType: 'select',
            elementConfig: {
                options : [
                    {value: 'Place 3',displayValue:'Place 3'},
                    {value: 'Place 4',displayValue:'Place 4'}
                ]
            },
            value: 'Place 3',
            validation:{
                required: false
            },
            touched: false
        },
        {
            name : 'Time',
            elementType: 'select',
            elementConfig: {
                options : [
                    {value: '8',displayValue:'8 AM'},
                    {value: '9',displayValue:'9 AM'}
                ]
            },
            value: '8',
            validation:{
                required: false
            },
            touched: false
        }
    ]

    const typDat = [
            {   
                name: 'Event',
                elementType: 'radio',
                value: 'event',
                validation:{
                    required: false
                },
                touched: false
            },
            {
                name: 'Bus',
                elementType: 'radio',
                value: 'bus',
                validation:{
                    required: false
                },
                touched: false
            }
    ]

    const [drawtogg, toggSwitch] = useState(1)
    const [inputDet, chInpDet] = useState(filterDat)

    

    const orderhandler = () => {
        console.log("YO submitted!")
    }

    const inputChangedHandler = (event, inputIdentifier) => {
        const updatedOrderForm = {
            ...inputDet
        }
        const updatedFormElement = {
            ...updatedOrderForm[inputIdentifier]
        }
        updatedFormElement.value = event.target.value
        updatedFormElement.touched = true
        updatedOrderForm[inputIdentifier] = updatedFormElement

    }


    useEffect (() => {
        if(drawtogg){
            chInpDet(filterDat)
        }
        else{
            chInpDet(typDat)
        }
    }, [drawtogg])
    
    return(
        <Aux>
            {/* <Backdrop show={props.open} clicked={props.closed} /> */}
            <div className={attachedClassesEin.join(' ')}>
                <div className={classes.filterButton}>
                    <Button  clicked={()=> toggSwitch(1)}>Filter</Button>
                </div>
                <div className={classes.typesButton}>
                <Button clicked={()=> toggSwitch(0)}>Types</Button>
                </div>
                <form onSubmit={orderhandler}>{
                    inputDet.map(formElement =>(
                        <Aux>
                            <text className={classes.textName}>{formElement.name}</text>
                            <Input 
                            key={formElement.id}
                            elementType={formElement.elementType}
                            elementConfig={formElement.elementConfig}
                            value={formElement.value}
                            touched={formElement.touched}
                            shouldValidate={formElement.validation}
                            changed={(event) => inputChangedHandler(event,formElement.id)}/>
                            
                        </Aux>
                        
                    ))}
                    <Button btnType="Success" >Submit</Button>     
                </form>
                <img src={leftArro} className={classes.leftArr} alt="leftArrow" onClick={props.sideDrawClose}/>
            </div>
            
        </Aux>
        
    )

};

export default sideDrawer