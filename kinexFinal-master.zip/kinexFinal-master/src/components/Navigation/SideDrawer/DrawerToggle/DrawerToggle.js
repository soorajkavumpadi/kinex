import React from "react";
import classes from "./DrawerToggle.module.css";
import rightArro from "../../../../assets/icons/right-arrow.svg";

const drawerToggle = (props) =>{
    console.log(props.show)
    if(props.show){
        return(
            <div className ={classes.DrawerToggle} onClick={props.clicked} >
                <img src={rightArro} alt="rightArrow"/>
             </div>
        )   
    }
    else
        return null
}
    

export default drawerToggle;
