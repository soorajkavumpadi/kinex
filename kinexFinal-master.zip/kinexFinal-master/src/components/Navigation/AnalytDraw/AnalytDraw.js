import React from "react";
import classes from "./AnalytDraw.module.css";
import NavigationItems from "../NavigationItems/NavigationItems";
import Aux from "../../../hoc/auxiliar";
import {Route} from "react-router-dom";
/*import { router } from "sw-toolbox";*/

const AnalytDraw = props => (
  <Aux>
    <Route>
      <div className={classes.analytDraw}>
        <nav>
          
                    <NavigationItems />
                </nav>
                
            </div>
            
        </Route>
        
  </Aux>
);

export default AnalytDraw;
