import React from 'react'
import classes from './NavigationItems.module.css'
import NavigationItem from './NavigationItem/NavigationItem';

import geoIcon from '../../../assets/icons/location.svg'
import tableIcon from '../../../assets/icons/table-for-data.svg'
import analyticIcon from '../../../assets/icons/analytics.svg'
import ListIcon from '../../../assets/icons/list.svg'

const navigationItems = (props) =>(
    <ul className={classes.NavigationItems}>
        
        <NavigationItem link="/geo" exact><img src={geoIcon} alt="geoIcon" className={classes.NavigationItem}/></NavigationItem>
        <NavigationItem link="/list" exact><img src={ListIcon} alt="ListIcon" className={classes.NavigationItem}/></NavigationItem>
        <NavigationItem link="/table" exact><img src={tableIcon} alt="tableIcon" className={classes.NavigationItem}/></NavigationItem>
        <NavigationItem link="/analytics" exact><img src={analyticIcon} alt="analyticIcon" className={classes.NavigationItem}/></NavigationItem>
    </ul>
)

export default navigationItems