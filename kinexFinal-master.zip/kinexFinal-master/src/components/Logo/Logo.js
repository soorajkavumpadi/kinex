import React from 'react'

import classes from './Logo.module.css'
import kinexLogo from '../../assets/Images/kinex.svg'

const logo = (props) => (
    <div className={classes.Logo}>
        <img src={kinexLogo} className={classes.Logo_img} alt="Kinexlogo"/>
    </div>
);

export default logo;