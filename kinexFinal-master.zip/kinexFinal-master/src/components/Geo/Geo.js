import React, { Component } from "react";
import {
  Map,
  GoogleApiWrapper,
  Polyline,
  InfoWindow,
  Marker
} from "google-maps-react";
import Layout from '../../hoc/Layout/Layout'
import classes from './Geo.module.css';
const cords = [9.9312, 76.2673 | 9.8745, 76.3704];


const mapStyles = [
  {
    strictBounds: "cords",
    width: "100%",
    height: "100%",
    cursor: "default",
    draggableCursor: "none",
    draggingCursor: "none"
  },

  {
    featureType: "administrative",
    elementType: "geometry",
    stylers: [
      {
        visibility: "off"
      }
    ]
  },
  {
    featureType: "landscape",
    stylers: [
      {
        color: "#ffffff"
      }
    ]
  },
  {
    featureType: "poi",
    stylers: [
      {
        visibility: "off"
      }
    ]
  },
  {
    featureType: "road",
    stylers: [
      {
        visibility: "off"
      }
    ]
  },
  {
    featureType: "road",
    elementType: "labels.icon",
    stylers: [
      {
        visibility: "off"
      }
    ]
  },
  {
    featureType: "transit",
    stylers: [
      {
        visibility: "off"
      }
    ]
  }
];

export class Geo extends Component {
  constructor() {
    super();
    this.state = {
      announcements: [],
      loading: true,
      showingInfoWindow: false,
      activeMarker: {},
      activePolyline: {},
      selectedPlace: {}
    };
  }

  onMarkerClick = (props, marker, Polyline, e) =>
    this.setState({
      selectedPlace: props,
      activeMarker: marker,
      activePolyline: Polyline,
      showingInfoWindow: true
    });

  onMapClicked = props => {
    if (this.state.showingInfoWindow) {
      this.setState({
        showingInfoWindow: false,
        activeMarker: null,
        activePolyline: null
      });
    }
  };
  render() {
    const pathCoordinates = [
      [
        { lat: 9.9312, lng: 76.2673 },
        { lat: 9.9412, lng: 76.2873 },
        { lat: 9.9512, lng: 76.2973 },
        { lat: 9.9612, lng: 76.3073 },
        { lat: 9.9712, lng: 76.3273 },
        { lat: 9.9812, lng: 76.3473 },
        { lat: 9.9912, lng: 76.3673 },
        { lat: 10.1312, lng: 76.3873 },
        { lat: 9.9412, lng: 76.2873 },
        { lat: 9.9512, lng: 76.2973 },
        { lat: 9.9612, lng: 76.3073 },
        { lat: 9.9712, lng: 76.3273 },
        { lat: 9.9812, lng: 76.3473 },
        { lat: 9.9912, lng: 76.3673 }
      ],
      [
        { lat: 9.9322, lng: 76.2673 },
        { lat: 10.9412, lng: 76.2873 },
        { lat: 10.9512, lng: 76.2973 },
        { lat: 9.9612, lng: 76.3073 },
        { lat: 9.9712, lng: 76.3273 },
        { lat: 9.9812, lng: 76.3473 },
        { lat: 9.9912, lng: 76.3673 },
        { lat: 10.1312, lng: 76.3873 },
        { lat: 9.9412, lng: 76.2873 },
        { lat: 9.9512, lng: 76.2973 },
        { lat: 9.9612, lng: 76.3073 },
        { lat: 9.9712, lng: 76.3273 },
        { lat: 9.9812, lng: 76.3473 },
        { lat: 9.9912, lng: 76.3673 }
      ]
    ];

    const pathMove = [200, 300];

    return (
      <Layout>
        <Map
        mapfitBounds={cords}
        google={this.props.google}
        onClick={this.onMapClicked}
        minZoom={12}
        maxZoom={15}
        getBounds={pathCoordinates}
        styles={mapStyles}
        zoomControl={true}
        disableDoubleClickZoom={true}
        cursorType={"pointer"}
        fullscreenControl={false}
        streetViewControl={false}
        mapTypeControl={false}
        initialCenter={{
          lat: 9.9312,
          lng: 76.2673
        }}
      >
        <Marker onClick={this.onMarkerClick} name={"Current location"} />
        {pathCoordinates.map(pathCor => {
          pathMove.map(pathConc => {
            const strokeWgt = pathConc;
            console.log(strokeWgt);
          });
          return (
            <Polyline
              path={pathCor}
              options={{
                strokeColor: "#000fff",
                strokeOpacity: 1,
                strokeWeight: this.strokeWgt / 100
              }}
              name={"details"}
            />
          );
        })}

        <InfoWindow
          onOpen={this.windowHasOpened}
          onClose={this.windowHasClosed}
          Polyline={this.state.activePolyline}
          marker={this.state.activeMarker}
          visible={this.state.showingInfoWindow}
        >
          <div>
            <h1>{this.state.selectedPlace.name}</h1>
          </div>
        </InfoWindow>
      </Map>
      </Layout>
      
    );
  }
}

export default GoogleApiWrapper({
  apiKey: "AIzaSyC8_5SUGihjx9_5-DW12_64hkFfYQMn3CU"
})(Geo);
