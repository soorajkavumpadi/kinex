import React, {Component} from 'react';
import Beijing from '../../assets/Images/Beijing_map.png';
import Aux from '../auxiliar'
import Toolbar from '../../components/Navigation/Toolbar/Toolbar'
import classes from './Layout.module.css'
import SideDrawer from '../../components/Navigation/SideDrawer/SideDrawer'
import DrawerToggle from '../../components/Navigation/SideDrawer/DrawerToggle/DrawerToggle'
import AnalytDraw from '../../components/Navigation/AnalytDraw/AnalytDraw'
import Logo from '../../components/Logo/Logo'

class Layout extends Component {
    state = {
        showSideDrawer : false
    }

    sideDrawerClosedHandler = () =>{
        this.setState({showSideDrawer : false})
    }

    sideDrawerToggleHandler = () => {
        this.setState((prevState) => {
            return{
                showSideDrawer : !prevState.showSideDrawer
            }
        })
    }

    render() {
        return(
            <Aux>
                {/* <h1>Mr. Layout here</h1> */}
               
                <Logo className={classes.Logo}/>
                <AnalytDraw /> 
                
                <DrawerToggle clicked={this.sideDrawerToggleHandler} show={!this.state.showSideDrawer}/>
                <SideDrawer 
                    open={this.state.showSideDrawer}
                    closed={this.sideDrawerClosedHandler}
                    sideDrawClose={this.sideDrawerClosedHandler} />
                <main className={classes.Content}>
                    {this.props.children} 
                    
                </main> 
            </Aux>
        )
    }
}

export default Layout;