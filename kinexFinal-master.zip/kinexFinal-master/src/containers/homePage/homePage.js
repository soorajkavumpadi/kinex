import React, { Component } from "react";
import Input from "../../components/UI/Input/Input";
import Button from "../../components/UI/Button/Button";
import classes from "./homePage.module.css";
import Logo from '../../components/Logo/Logo'
import NavigationItem from '../../components/Navigation/NavigationItems/NavigationItem/NavigationItem'



class homePage extends Component {
  state = {
    login: false,
    orderForm: {
      email: {
        elementType: "input",
        elementConfig: {
          type: "text"
        },
        value: "",
        validation: {
          required: true
        },
        valid: false,
        touched: false
      },
      password: {
        elementType: "input",
        elementConfig: {
          type: "text"
        },
        value: "",
        validation: {
          required: true
        },
        valid: false,
        touched: false
      }
    },
    formIsValid: false,
    loading: false
  };

  checkValidity(value, rules) {
    let isValid = true;
    if (!rules) return true;
    if (rules.required) isValid = value.trim() !== "" && isValid;
    if (rules.minLength) isValid = value.length >= rules.maxLength && isValid;
    if (rules.maxLength) isValid = value.length <= rules.maxLength && isValid;
    return isValid;
  }

  inputChangedHandler = (event, inputIdentifier) => {
    const updatedOrderForm = {
      ...this.state.orderForm
    };
    const updatedFormElement = {
      ...updatedOrderForm[inputIdentifier]
    };
    updatedFormElement.value = event.target.value;
    updatedFormElement.valid = this.checkValidity(
      updatedFormElement.value,
      updatedFormElement.validation
    );
    updatedFormElement.touched = true;
    updatedOrderForm[inputIdentifier] = updatedFormElement;

    let formIsValid = true;
    for (let inputIdentifier in updatedOrderForm) {
      formIsValid = updatedOrderForm[inputIdentifier].valid && formIsValid;
    }
    this.setState({ orderForm: updatedOrderForm, formIsValid: formIsValid });
  };

  render() {
    return (
      <div className={classes.background} >
        <text className={classes.copyright_text} >
        copyright 2019 Team Kinex©
        </text>
        <div className={classes.Logo} id="common" >
        <Logo/>
        </div>
        

        <text
          className={classes.about_text} id="common"
          type="button"
          onClick={event => this.handleClick(event)}
        >
          {" "}
          ABOUT{" "}
        </text>
        <text
          className={classes.help_text} id="common"
          type="button"
          onClick={event => this.handleClick(event)}
        >
          HELP
        </text>
        <text className={classes.username_text}  type="text">
          Username
        </text>
        <text className={classes.intro_text} type="text">
          Crowd-tracking
          <br />
          and analysis.
        </text>

        <div className={classes.username_input}>
          <Input
            key="userId"
            elementType={this.state.orderForm.email.elementType}
            elementConfig={this.state.orderForm.email.elementConfig}
            value={this.state.orderForm.email.value}
            invalid={!this.state.orderForm.email.valid}
            touched={this.state.orderForm.email.touched}
            shouldValidate={this.state.orderForm.email.validation}
            changed={event => this.inputChangedHandler(event, "userId")}
          />
        </div>

        <text className={classes.password_text}>Password</text>
        <div className={classes.password_input}>
          <Input
            key="password"
            elementType={this.state.orderForm.password.elementType}
            elementConfig={this.state.orderForm.password.elementConfig}
            value={this.state.orderForm.password.value}
            invalid={!this.state.orderForm.password.valid}
            touched={this.state.orderForm.password.touched}
            shouldValidate={this.state.orderForm.password.validation}
            changed={event => this.inputChangedHandler(event, "password")}
          />
        </div>
        <div className={classes.login_button}>
        <NavigationItem link="/geo" exact>
          <Button btnType="Success" >
            LOGIN
          </Button>
          </NavigationItem>
        </div>
        <text
          className={classes.forgot_text}
          type="button"
          onClick={event => this.handleClick(event)}
        >
         FORGOT PASSWORD?
        </text>
      </div>
    );
  }
}

export default homePage;
